package main.com.capgemini;
import bean.com.capgemini.Customer;
import java.math.BigDecimal;
import service.com.capgemini.Serviceimpl;
import java.util.*;

public class Client {
	public static void main(String[] args)
	{
		Serviceimpl serve= new Serviceimpl();
		Customer ct;
		
		serve.CreateAccount("aditi","981867459",new BigDecimal(5000.00));
	
		
		serve.CreateAccount("kriti","98674848",new BigDecimal(78557.00));
		serve.CreateAccount("arshad","98185454",new BigDecimal(8977.00));
		serve.CreateAccount("bhavesh","96788888",new BigDecimal(5890.00));
		serve.CreateAccount("harsh","988966790",new BigDecimal(5567.00));
	
		
		ct=serve.showbalance("981867459");
		System.out.println(ct.getWallet().getAmount());
		serve.showbalance("98674848");
		serve.showbalance("98185454");
		serve.showbalance("96788888");
		serve.showbalance("988966790");
		
	}
	}