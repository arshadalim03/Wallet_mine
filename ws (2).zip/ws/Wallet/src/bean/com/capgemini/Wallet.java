package bean.com.capgemini;
import java.math.BigDecimal;
public class Wallet {
	
	private BigDecimal amount;

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

}
