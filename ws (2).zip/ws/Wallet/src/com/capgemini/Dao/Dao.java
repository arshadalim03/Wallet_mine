package com.capgemini.Dao;
import java.math.BigDecimal;
import bean.com.capgemini.Customer;

public interface Dao {
	
		public Customer CreateAccount(String name, int mobile, BigDecimal amount);
		public Customer Showbalance(String mobile);

	}



