package service.com.capgemini;

import java.math.BigDecimal;

import com.capgemini.Dao.Daoimpl;

import bean.com.capgemini.Customer;
import bean.com.capgemini.Wallet;

public class Serviceimpl implements Serviceinterface{
	Daoimpl dao= new Daoimpl();
	public Customer CreateAccount(String name, String mobile, BigDecimal amount) {
		Customer customer= new Customer();
		Wallet wallet= new Wallet();
		customer.setCustname(name);
		customer.setMobile(mobile);
		wallet.setAmount(amount);
		dao.CreateAccount(customer);
		return customer;
		
		
	}
	public Customer showbalance(String mobile) {
		

		Customer customer= new Customer();

		dao.Showbalance(mobile);
		return customer;
		
		
		
	}


}

